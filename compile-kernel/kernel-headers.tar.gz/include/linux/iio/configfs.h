/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Industrial I/O configfs support
 *
 * Copyright (c) 2015 Intel Corporation
 */
#ifndef __IIO_CONFIGFS
#define __IIO_CONFIGFS

extern struct configfs_subsystem iio_configfs_subsys;

#endif /* __IIO_CONFIGFS */
